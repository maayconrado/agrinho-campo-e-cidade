let perguntas = []; // Array que guarda todas as perguntas do nosso jogo
let perguntaAtualIndex = 0; // Qual pergunta estamos mostrando agora (começa na primeira)
let pontuacao = 0; // Quantos pontos o jogador fez
let estadoJogo = 'jogando'; // O jogo começa direto na primeira pergunta
let feedbackTexto = ''; // Texto que mostra "Certo!" ou "Errado!"
let corFeedback; // Cor do texto de feedback (verde ou vermelho)
let tempoExibindoFeedback = 0; // Contador para o feedback sumir depois de um tempo
const DURACAO_FEEDBACK = 60; // Quantos frames o feedback fica na tela (aprox. 1 segundo)

// Cores para o fundo e elementos visuais
let corCeuManha = [173, 216, 230]; // Azul claro suave
let corSol = [255, 220, 0];       // Amarelo para o sol
let corGramado = [100, 180, 100]; // Verde mais vibrante
let corPredioClaro = [150];       // Cinza claro para prédios
let corPredioEscuro = [100];      // Cinza escuro para prédios
let corEstrada = [80];            // Cinza escuro para a estrada

function setup() {
  createCanvas(800, 550); // Cria uma tela um pouco maior para o jogo
  textAlign(CENTER, CENTER); // Alinha todo o texto ao centro
  textSize(24);            // Tamanho padrão do texto

  // Configurações para o texto da pergunta
  textLeading(30); // Espaçamento entre as linhas de texto (ajuste se precisar)
  textWrap(WORD); // Faz o texto quebrar em palavras, se a largura for limitada

  // Nossas 6 perguntas inteligentes sobre Campo e Cidade
  // Cada pergunta tem um texto, duas opções e a resposta correta
  perguntas = [
    {
      texto: "Qual ambiente é mais propício ao desenvolvimento de uma agricultura de larga escala?",
      opcao1: "Cidade",
      opcao2: "Campo",
      respostaCorreta: "Campo"
    },
    {
      texto: "Onde o fenômeno das 'ilhas de calor' urbanas é mais comum?",
      opcao1: "Cidade",
      opcao2: "Campo",
      respostaCorreta: "Cidade"
    },
    {
      texto: "Qual cenário é geralmente associado a uma maior biodiversidade nativa?",
      opcao1: "Cidade",
      opcao2: "Campo",
      respostaCorreta: "Campo"
    },
    {
      texto: "Onde a infraestrutura de transporte público (metrôs, grandes terminais) é mais desenvolvida?",
      opcao1: "Cidade",
      opcao2: "Campo",
      respostaCorreta: "Cidade"
    },
    {
      texto: "Em qual ambiente a poluição luminosa tende a ser um problema maior para a observação astronômica?",
      opcao1: "Cidade",
      opcao2: "Campo",
      respostaCorreta: "Cidade"
    },
    {
      texto: "Qual paisagem é mais caracterizada pela presença de ecossistemas florestais ou campos abertos?",
      opcao1: "Cidade",
      opcao2: "Campo",
      respostaCorreta: "Campo"
    }
  ];
}

function draw() {
  // Desenha o fundo mais legal, com elementos de campo e cidade
  desenharFundoAbstrato();

  // Desenha o jogo de acordo com o estado atual
  if (perguntaAtualIndex < perguntas.length) {
    desenharTelaJogo(); // Mostra a pergunta e as opções
  } else {
    desenharTelaFinal(); // Mostra o resultado final do jogo
  }
}

// --- Funções para Desenhar ---

function desenharFundoAbstrato() {
  background(corCeuManha[0], corCeuManha[1], corCeuManha[2]); // Céu azul claro

  // Campo (lado esquerdo)
  fill(corGramado[0], corGramado[1], corGramado[2]);
  rect(0, height * 0.5, width / 2, height * 0.5); // Gramado até a metade da tela

  // Sol no canto do campo
  fill(corSol[0], corSol[1], corSol[2]);
  ellipse(width * 0.25, height * 0.2, 100, 100);

  // Cidade (lado direito)
  fill(corEstrada[0]);
  rect(width / 2, height * 0.7, width / 2, height * 0.3); // "Estrada" na parte inferior direita

  // Desenha alguns prédios simples na cidade
  noStroke();
  fill(corPredioClaro[0]);
  rect(width * 0.55, height * 0.4, 60, height * 0.3);
  fill(corPredioEscuro[0]);
  rect(width * 0.65, height * 0.3, 70, height * 0.4);
  fill(corPredioClaro[0]);
  rect(width * 0.75, height * 0.5, 50, height * 0.2);
  fill(corPredioEscuro[0]);
  rect(width * 0.85, height * 0.2, 80, height * 0.5);

  // Uma divisória simples entre campo e cidade
  stroke(255); // Linha branca
  strokeWeight(3); // Mais grossa
  line(width / 2, 0, width / 2, height);
  noStroke(); // Volta a não ter contorno para outros elementos
}


function desenharTelaJogo() {
  let perguntaAtual = perguntas[perguntaAtualIndex]; // Pega a pergunta da vez

  // Definindo as dimensões e posição da caixa da pergunta
  let caixaX = width / 2 - 300;
  let caixaY = 50;
  let caixaLargura = 600;
  let caixaAltura = 120; // Altura da caixa, talvez precise ajustar se a pergunta tiver muitas linhas

  // Desenha a caixa da pergunta
  fill(255, 255, 255, 240); // Branco mais opaco para o fundo da pergunta
  noStroke();
  rect(caixaX, caixaY, caixaLargura, caixaAltura, 20); // Caixa arredondada

  // Desenha o texto da pergunta
  fill(0); // Cor preta para o texto
  textSize(26);

  // **MUDANÇA CHAVE AQUI:** Usamos text() com 4 parâmetros para delimitar a largura
  // O texto será desenhado dentro do retângulo definido por (caixaX, caixaY, caixaLargura, caixaAltura)
  text(perguntaAtual.texto, caixaX, caixaY, caixaLargura, caixaAltura);


  // Desenha a pontuação no canto
  textSize(20);
  textAlign(LEFT, TOP); // Para a pontuação ficar no canto superior esquerdo
  fill(0);
  text("Pontos: " + pontuacao, 20, 20);
  textAlign(CENTER, CENTER); // Volta o alinhamento para o centro para o resto do jogo

  // --- Desenha as opções de resposta como botões ---
  let xBotao = width / 2 - 120; // Posição X para os botões
  let larguraBotao = 240;
  let alturaBotao = 60;
  let espacoEntreBotoes = 25;

  // Opção 1
  let yBotao1 = height / 2;
  desenharBotao(xBotao, yBotao1, larguraBotao, alturaBotao, perguntaAtual.opcao1);

  // Opção 2
  let yBotao2 = yBotao1 + alturaBotao + espacoEntreBotoes;
  desenharBotao(xBotao, yBotao2, larguraBotao, alturaBotao, perguntaAtual.opcao2);

  // Desenha o feedback (Certo!/Errado!) se estiver ativo
  if (tempoExibindoFeedback > 0) {
    fill(corFeedback);
    textSize(40);
    text(feedbackTexto, width / 2, height - 70);
    tempoExibindoFeedback--; // Diminui o contador
  }
}

function desenharBotao(x, y, w, h, textoBotao) {
  // Muda a cor do botão ao passar o mouse por cima
  if (mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h) {
    fill(100, 150, 250); // Azul claro mais forte
    cursor(HAND); // Muda o cursor para uma mãozinha
  } else {
    fill(120, 180, 250); // Azul claro padrão
    cursor(ARROW); // Volta o cursor normal
  }
  rect(x, y, w, h, 10); // Desenha o retângulo do botão com bordas arredondadas
  fill(255); // Cor branca para o texto do botão
  textSize(22);
  text(textoBotao, x + w / 2, y + h / 2); // Desenha o texto dentro do botão
}

function desenharTelaFinal() {
  fill(255, 255, 255, 220); // Fundo semi-transparente para o texto final
  noStroke();
  rect(width / 2 - 250, height / 2 - 150, 500, 300, 20);

  fill(0);
  textSize(40);
  text("Fim do Jogo!", width / 2, height / 2 - 80);

  textSize(30);
  text("Sua Pontuação Final: " + pontuacao + " pontos", width / 2, height / 2 - 20);

  // Mensagem de parabéns baseada na pontuação
  if (pontuacao >= 40) { // Se fez 40 pontos ou mais (pelo menos 4 acertos)
    textSize(28);
    fill(0, 150, 0); // Verde vibrante
    text("Parabéns, você é um mestre!", width / 2, height / 2 + 50);
  } else if (pontuacao >= 20) { // Se fez 20 pontos ou mais
    textSize(26);
    fill(0, 0, 180); // Azul escuro
    text("Muito bom, continue aprendendo!", width / 2, height / 2 + 50);
  } else { // Menos de 20 pontos
    textSize(26);
    fill(180, 0, 0); // Vermelho
    text("Tente novamente para melhorar!", width / 2, height / 2 + 50);
  }

  // Botão para jogar novamente
  let xBotaoRecomecar = width / 2 - 125;
  let yBotaoRecomecar = height - 100;
  let larguraBotaoRecomecar = 250;
  let alturaBotaoRecomecar = 60;

  desenharBotao(xBotaoRecomecar, yBotaoRecomecar, larguraBotaoRecomecar, alturaBotaoRecomecar, "Jogar Novamente");
}

// --- Funções de Interação ---

function mousePressed() {
  // Verifica se o jogo já terminou
  if (perguntaAtualIndex >= perguntas.length) {
    // Se clicou no botão "Jogar Novamente"
    let xBotaoRecomecar = width / 2 - 125;
    let yBotaoRecomecar = height - 100;
    let larguraBotaoRecomecar = 250;
    let alturaBotaoRecomecar = 60;

    if (mouseX > xBotaoRecomecar && mouseX < xBotaoRecomecar + larguraBotaoRecomecar &&
        mouseY > yBotaoRecomecar && mouseY < yBotaoRecomecar + alturaBotaoRecomecar) {
      // Reinicia o jogo
      perguntaAtualIndex = 0;
      pontuacao = 0;
      feedbackTexto = '';
      tempoExibindoFeedback = 0;
    }
    return; // Sai da função, pois já lidamos com o clique
  }

  // Se o jogo está rolando e o feedback não está sendo exibido
  if (tempoExibindoFeedback === 0) {
    let perguntaAtual = perguntas[perguntaAtualIndex];
    let xBotao = width / 2 - 120;
    let larguraBotao = 240;
    let alturaBotao = 60;
    let espacoEntreBotoes = 25;

    // Verifica o clique na Opção 1
    let yBotao1 = height / 2;
    if (mouseX > xBotao && mouseX < xBotao + larguraBotao &&
        mouseY > yBotao1 && mouseY < yBotao1 + alturaBotao) {

      processarResposta(perguntaAtual.opcao1 === perguntaAtual.respostaCorreta);
      return; // Sai após processar o clique
    }

    // Verifica o clique na Opção 2
    let yBotao2 = yBotao1 + alturaBotao + espacoEntreBotoes;
    if (mouseX > xBotao && mouseX < xBotao + larguraBotao &&
        mouseY > yBotao2 && mouseY < yBotao2 + alturaBotao) {

      processarResposta(perguntaAtual.opcao2 === perguntaAtual.respostaCorreta);
      return; // Sai após processar o clique
    }
  }
}

function processarResposta(acertou) {
  if (acertou) {
    pontuacao += 10; // Adiciona 10 pontos por acerto
    feedbackTexto = "Certo!";
    corFeedback = color(0, 180, 0); // Verde para "Certo!"
  } else {
    feedbackTexto = "Errado!";
    corFeedback = color(200, 0, 0); // Vermelho para "Errado!"
  }

  tempoExibindoFeedback = DURACAO_FEEDBACK; // Ativa o feedback por 1 segundo (60 frames)

  // Avança para a próxima pergunta depois que o feedback sumir
  setTimeout(() => {
    perguntaAtualIndex++; // Vai para a próxima pergunta
    feedbackTexto = ''; // Limpa o feedback
  }, DURACAO_FEEDBACK / 60 * 1000); // Converte frames para milissegundos
}